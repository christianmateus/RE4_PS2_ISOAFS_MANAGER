namespace FerramentaAFS
{
    public partial class Form1
    {
        private void ConfigurarBatchIndexado()
        {
        }
    }
}
