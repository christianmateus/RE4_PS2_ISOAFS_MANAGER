using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace FerramentaAFS
{
    public partial class Form1
    {
        private void MenuImportarSelecionado_Click(object? sender, EventArgs e)
        {
            if (_afsPath == null)
            {
                MessageBox.Show("Abra um arquivo AFS primeiro.", "Ferramenta AFS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (dgvArquivos.SelectedRows.Count == 0 || dgvArquivos.SelectedRows[0].Tag is not AfsEntry entry)
            {
                MessageBox.Show("Selecione uma entrada para importar.", "Ferramenta AFS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (entry.IsEmpty)
            {
                MessageBox.Show("Não é possível importar sobre uma entrada vazia.", "Ferramenta AFS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string nomeAtual = string.IsNullOrWhiteSpace(entry.FileName) ? $"File_{entry.Index:D4}" : entry.FileName;

            using OpenFileDialog dialog = new OpenFileDialog
            {
                Title = $"Importar sobre {nomeAtual}",
                Filter = "Todos os arquivos (*.*)|*.*",
                FileName = Path.GetFileName(nomeAtual)
            };

            if (dialog.ShowDialog() != DialogResult.OK)
                return;

            FileInfo novoArquivo = new FileInfo(dialog.FileName);

            if (novoArquivo.Length > entry.AllocatedSize)
            {
                MessageBox.Show(
                    $"O arquivo é maior que o espaço disponível desta entrada.\n\nArquivo novo: {novoArquivo.Length:N0} bytes\nMax Size: {entry.AllocatedSize:N0} bytes\nExcesso: {(novoArquivo.Length - entry.AllocatedSize):N0} bytes\n\nNesta etapa, a importação é In-Place e não move as entradas seguintes.",
                    "Arquivo grande demais",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (ArquivoEhIdenticoAoAfs(entry, dialog.FileName))
            {
                MessageBox.Show("O arquivo selecionado já é idêntico ao conteúdo atual da entrada. Nenhuma alteração foi feita.", "Arquivo idêntico", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult confirmacao = MessageBox.Show(
                $"Substituir a entrada selecionada?\n\nNome: {nomeAtual}\nCurrent Size: {ObterTamanhoReal(entry):N0} bytes\nNovo tamanho: {novoArquivo.Length:N0} bytes\nMax Size: {entry.AllocatedSize:N0} bytes\n\nO conteúdo será substituído no mesmo slot físico. A alocação atual será preservada.",
                "Confirmar importação",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirmacao != DialogResult.Yes)
                return;

            try
            {
                ImportarEntradaInPlace(entry, dialog.FileName);
                ReabrirAfsAtualPreservandoBusca(entry.Index);

                MessageBox.Show($"Importação concluída.\n\n{nomeAtual}\nNovo Current Size: {novoArquivo.Length:N0} bytes", "Importação concluída", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro durante a importação:\n\n{ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ImportarEntradaInPlace(AfsEntry entry, string caminhoNovoArquivo)
        {
            if (_afsPath == null)
                throw new InvalidOperationException("Nenhum AFS está aberto.");

            using Stream afs = AbrirAfsStream(FileAccess.ReadWrite, FileShare.None);
            ImportarEntradaInPlace(afs, entry, caminhoNovoArquivo);
            afs.Flush();
        }

        private void ImportarEntradaInPlace(Stream afs, AfsEntry entry, string caminhoNovoArquivo)
        {
            FileInfo novoArquivo = new FileInfo(caminhoNovoArquivo);

            if (!novoArquivo.Exists)
                throw new FileNotFoundException("O arquivo de importação não existe.", caminhoNovoArquivo);

            if (novoArquivo.Length > uint.MaxValue)
                throw new InvalidDataException("O arquivo é grande demais para o campo de tamanho do AFS.");

            if (novoArquivo.Length > entry.AllocatedSize)
                throw new InvalidDataException($"O arquivo '{novoArquivo.Name}' possui {novoArquivo.Length:N0} bytes, mas a entrada só permite {entry.AllocatedSize:N0} bytes.");

            if ((long)entry.Offset + entry.AllocatedSize > afs.Length)
                throw new InvalidDataException($"O slot físico da entrada {entry.Index} ultrapassa os limites do AFS.");

            afs.Position = entry.Offset;

            using (FileStream origem = new FileStream(caminhoNovoArquivo, FileMode.Open, FileAccess.Read, FileShare.Read))
                origem.CopyTo(afs, 1024 * 1024);

            long restanteSlot = entry.AllocatedSize - novoArquivo.Length;

            if (restanteSlot > 0)
                PreencherComZeros(afs, restanteSlot);

            DateTime agora = DateTime.Now;
            AtualizarTocDaEntrada(afs, entry, (uint)novoArquivo.Length, agora);

            entry.ActualSize = (uint)novoArquivo.Length;
            entry.TocYear = (ushort)agora.Year;
            entry.TocMonth = (ushort)agora.Month;
            entry.TocDay = (ushort)agora.Day;
            entry.TocHour = (ushort)agora.Hour;
            entry.TocMinute = (ushort)agora.Minute;
            entry.TocSecond = (ushort)agora.Second;
        }

        private void AtualizarTocDaEntrada(Stream afs, AfsEntry entry, uint novoTamanho, DateTime timestamp)
        {
            if (_tocOffset == 0 || _tocSize < (_entries.Count * 48L))
                throw new InvalidDataException("A TOC de 48 bytes não foi encontrada. A importação segura exige a TOC para atualizar o Current Size.");

            long metadataOffset = (long)_tocOffset + ((long)entry.Index * 48L) + 32L;

            if (metadataOffset < 0 || metadataOffset + 16 > afs.Length)
                throw new InvalidDataException("O metadata da entrada está fora dos limites físicos do AFS.");

            afs.Position = metadataOffset;

            using BinaryWriter bw = new BinaryWriter(afs, System.Text.Encoding.UTF8, leaveOpen: true);
            bw.Write((ushort)timestamp.Year);
            bw.Write((ushort)timestamp.Month);
            bw.Write((ushort)timestamp.Day);
            bw.Write((ushort)timestamp.Hour);
            bw.Write((ushort)timestamp.Minute);
            bw.Write((ushort)timestamp.Second);
            bw.Write(novoTamanho);
        }

        private static void PreencherComZeros(Stream stream, long quantidade)
        {
            byte[] zeros = new byte[1024 * 1024];
            long restante = quantidade;

            while (restante > 0)
            {
                int escrever = (int)Math.Min(zeros.Length, restante);
                stream.Write(zeros, 0, escrever);
                restante -= escrever;
            }
        }

        private static void MostrarArquivosGrandesDemais(List<ImportacaoPlanejada> grandes)
        {
            if (grandes.Count == 0)
                return;

            string texto = string.Join(
                Environment.NewLine,
                grandes.Take(25).Select(x => $"Index {x.Entry.Index:D6} | {x.Entry.FileName} | Novo: {x.NovoTamanho:N0} | Max: {x.Entry.AllocatedSize:N0}"));

            if (grandes.Count > 25)
                texto += $"{Environment.NewLine}... e mais {grandes.Count - 25:N0} arquivo(s).";

            MessageBox.Show(
                "Os arquivos abaixo não foram importados porque excedem o Max Size da entrada:\n\n" + texto,
                "Arquivos grandes demais",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }

        private void ReabrirAfsAtualPreservandoBusca(int? selecionarIndex)
        {
            if (_afsPath == null)
                return;

            string busca = txtBuscar.Text;

            AbrirAfsAtual();
            txtBuscar.Text = busca;

            if (!selecionarIndex.HasValue)
                return;

            foreach (DataGridViewRow row in dgvArquivos.Rows)
            {
                if (row.Tag is AfsEntry item && item.Index == selecionarIndex.Value)
                {
                    row.Selected = true;
                    dgvArquivos.CurrentCell = row.Cells[0];
                    break;
                }
            }
        }

        private class ImportacaoPlanejada
        {
            public AfsEntry Entry { get; set; } = null!;
            public string Caminho { get; set; } = string.Empty;
            public long NovoTamanho { get; set; }
        }
    }
}
