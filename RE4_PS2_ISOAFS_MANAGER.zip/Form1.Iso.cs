using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace FerramentaAFS
{
    public partial class Form1
    {
        private string? _containerPath;
        private long _afsBaseOffset;
        private long _afsLogicalLength;
        private IsoFileEntry? _isoAfsEntry;
        private List<IsoFileEntry> _isoFiles = new List<IsoFileEntry>();

        private ToolStripMenuItem? _menuAbrirIso;
        private ToolStripMenuItem? _menuIso;
        private ToolStripMenuItem? _menuEscolherAfsIso;
        private ToolStripMenuItem? _menuRebuildNaIso;

        private void ConfigurarIso()
        {
            _menuAbrirIso = new ToolStripMenuItem("Abrir ISO PS2...");
            _menuAbrirIso.ShortcutKeys = Keys.Control | Keys.Shift | Keys.O;
            _menuAbrirIso.Click += MenuAbrirIso_Click;

            menuArquivo.DropDownItems.Insert(1, _menuAbrirIso);

            _menuIso = new ToolStripMenuItem("ISO");
            _menuEscolherAfsIso = new ToolStripMenuItem("Escolher outro AFS da ISO...");
            _menuRebuildNaIso = new ToolStripMenuItem("Compactar / Rebuild diretamente na ISO...");

            _menuEscolherAfsIso.Click += MenuEscolherAfsIso_Click;
            _menuRebuildNaIso.Click += MenuRebuildNaIso_Click;

            _menuIso.DropDownItems.Add(_menuEscolherAfsIso);
            _menuIso.DropDownItems.Add(new ToolStripSeparator());
            _menuIso.DropDownItems.Add(_menuRebuildNaIso);
            _menuIso.Enabled = false;

            menuStrip1.Items.Add(_menuIso);
            AplicarTema();
        }

        private Stream AbrirAfsStream(FileAccess access, FileShare share)
        {
            if (_containerPath == null)
                throw new InvalidOperationException("Nenhum AFS está aberto.");

            return new BoundedFileStream(_containerPath, _afsBaseOffset, _afsLogicalLength, access, share);
        }

        private long ObterAfsLength() => _afsLogicalLength;

        private string ObterNomeAfsAtual()
        {
            if (_isoAfsEntry != null)
                return _isoAfsEntry.FullPath;

            return _containerPath != null ? Path.GetFileName(_containerPath) : "-";
        }

        private void AbrirAfsStandalone(string path)
        {
            _containerPath = path;
            _afsBaseOffset = 0;
            _afsLogicalLength = new FileInfo(path).Length;
            _isoAfsEntry = null;
            _isoFiles.Clear();
            if (_menuIso != null) _menuIso.Enabled = false;
            AbrirAfsAtual();
        }

        private void AbrirAfsDaIso(string isoPath, IsoFileEntry entry)
        {
            _containerPath = isoPath;
            _afsBaseOffset = entry.DataOffset;
            _afsLogicalLength = entry.Size;
            _isoAfsEntry = entry;
            if (_menuIso != null) _menuIso.Enabled = true;
            AbrirAfsAtual();
        }

        private void MenuAbrirIso_Click(object? sender, EventArgs e)
        {
            using OpenFileDialog dialog = new OpenFileDialog
            {
                Title = "Abrir ISO de PlayStation 2",
                Filter = "Imagens ISO (*.iso)|*.iso|Todos os arquivos (*.*)|*.*"
            };

            if (dialog.ShowDialog() != DialogResult.OK)
                return;

            try
            {
                toolStripStatusLabel1.Text = "Lendo ISO9660...";
                Application.DoEvents();

                _isoFiles = Iso9660Reader.ReadAllFiles(dialog.FileName);
                List<IsoFileEntry> afs = _isoFiles
                    .Where(x => !x.IsDirectory && x.Name.EndsWith(".AFS", StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(x => x.Size)
                    .ToList();

                if (afs.Count == 0)
                {
                    MessageBox.Show("Nenhum arquivo .AFS foi encontrado na ISO.", "ISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                IsoFileEntry? escolhido = EscolherAfs(afs);
                if (escolhido == null)
                    return;

                AbrirAfsDaIso(dialog.FileName, escolhido);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Não foi possível abrir a ISO.\n\n{ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MenuEscolherAfsIso_Click(object? sender, EventArgs e)
        {
            if (_containerPath == null || _isoFiles.Count == 0)
                return;

            List<IsoFileEntry> afs = _isoFiles
                .Where(x => !x.IsDirectory && x.Name.EndsWith(".AFS", StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(x => x.Size)
                .ToList();

            IsoFileEntry? escolhido = EscolherAfs(afs);
            if (escolhido != null)
                AbrirAfsDaIso(_containerPath, escolhido);
        }

        private IsoFileEntry? EscolherAfs(List<IsoFileEntry> afs)
        {
            if (afs.Count == 1)
                return afs[0];

            using Form form = new Form
            {
                Text = "AFS encontrados na ISO",
                StartPosition = FormStartPosition.CenterParent,
                Width = 760,
                Height = 480,
                MinimizeBox = false,
                MaximizeBox = false
            };

            ListBox list = new ListBox { Dock = DockStyle.Fill };
            Button ok = new Button { Text = "Abrir AFS", Dock = DockStyle.Bottom, Height = 38, DialogResult = DialogResult.OK };
            Button cancel = new Button { Text = "Cancelar", Dock = DockStyle.Bottom, Height = 38, DialogResult = DialogResult.Cancel };

            foreach (IsoFileEntry item in afs)
                list.Items.Add($"{item.FullPath}   [{FormatarBytes(item.Size)}]   LBA {item.Lba}");

            if (list.Items.Count > 0) list.SelectedIndex = 0;

            form.Controls.Add(list);
            form.Controls.Add(cancel);
            form.Controls.Add(ok);
            form.AcceptButton = ok;
            form.CancelButton = cancel;

            if (form.ShowDialog(this) != DialogResult.OK || list.SelectedIndex < 0)
                return null;

            return afs[list.SelectedIndex];
        }

        private void MenuRebuildNaIso_Click(object? sender, EventArgs e)
        {
            if (_containerPath == null || _isoAfsEntry == null)
            {
                MessageBox.Show("Abra um AFS diretamente de uma ISO primeiro.", "ISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                CompactPlan plan = CriarPlanoCompactacao();

                if (plan.NewFileSize > _isoAfsEntry.Size)
                {
                    MessageBox.Show(
                        $"O AFS reconstruído ficaria maior que a área atualmente reservada na ISO.\n\n" +
                        $"Área ISO: {FormatarBytes(_isoAfsEntry.Size)}\n" +
                        $"Rebuild: {FormatarBytes(plan.NewFileSize)}\n\n" +
                        "Esta versão bloqueia o crescimento para não deslocar outros arquivos da ISO.",
                        "Rebuild na ISO bloqueado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirm = MessageBox.Show(
                    $"Compactar o AFS diretamente dentro da ISO?\n\n" +
                    $"ISO: {Path.GetFileName(_containerPath)}\n" +
                    $"AFS: {_isoAfsEntry.FullPath}\n" +
                    $"Tamanho atual: {FormatarBytes(_isoAfsEntry.Size)}\n" +
                    $"Novo tamanho: {FormatarBytes(plan.NewFileSize)}\n" +
                    $"Economia: {FormatarBytes(_isoAfsEntry.Size - plan.NewFileSize)}\n\n" +
                    "Recomenda-se manter uma cópia de segurança da ISO.",
                    "Rebuild direto na ISO",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm != DialogResult.Yes)
                    return;

                string temp = Path.Combine(Path.GetTempPath(), $"afs_rebuild_{Guid.NewGuid():N}.afs");

                try
                {
                    ExecutarCompactacao(plan, temp);
                    ValidarAfsReconstruido(temp, plan);

                    using (FileStream iso = new FileStream(_containerPath, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                    using (FileStream rebuilt = new FileStream(temp, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        iso.Position = _isoAfsEntry.DataOffset;
                        rebuilt.CopyTo(iso, 1024 * 1024);

                        long restante = _isoAfsEntry.Size - rebuilt.Length;
                        byte[] zeros = new byte[1024 * 1024];

                        while (restante > 0)
                        {
                            int escrever = (int)Math.Min(zeros.Length, restante);
                            iso.Write(zeros, 0, escrever);
                            restante -= escrever;
                        }

                        iso.Flush(true);
                    }

                    Iso9660Reader.UpdateFileSize(_containerPath, _isoAfsEntry, checked((uint)plan.NewFileSize));
                    _afsLogicalLength = plan.NewFileSize;

                    AbrirAfsDaIso(_containerPath, _isoAfsEntry);

                    MessageBox.Show(
                        "AFS reconstruído diretamente na ISO e o tamanho da entrada ISO9660 foi atualizado.\n\n" +
                        "O LBA inicial foi preservado; nenhum arquivo posterior foi deslocado.",
                        "Rebuild na ISO concluído",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                finally
                {
                    try { if (File.Exists(temp)) File.Delete(temp); } catch { }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Falha no rebuild dentro da ISO.\n\n{ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
